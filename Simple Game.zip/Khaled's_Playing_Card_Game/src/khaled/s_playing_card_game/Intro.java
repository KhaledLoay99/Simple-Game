/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khaled.s_playing_card_game;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author Khaled
 */
public class Intro extends JFrame{
    Intro(){
     setTitle("Welcom TO The Game");
     setSize(400,400);
      try {
            setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\Khaled\\Desktop\\Green.jpg")).getScaledInstance(2000, 2000, Image.SCALE_DEFAULT))));
        } catch (IOException e) {
        }
        pack();
        setVisible(true);
     JButton button=new JButton("Play a New Game");
     button.setBackground(Color.LIGHT_GRAY);
     add(button);
     button.setBounds(700,500,400,100);
     JLabel label=new JLabel(" Welcome To Arrangement Game");
     label.setForeground(Color.white);
     label.setBounds(700, 100, 400, 100);
     label.setFont(new Font("Serif", Font.PLAIN, 29));    
     add(label);
      JButton button2=new JButton("Exit The Game ");
     button2.setBackground(Color.LIGHT_GRAY);
     add(button2);
     button2.setBounds(700,700,400,100);
     button.addActionListener(new press());
     button2.addActionListener(new press1());
    }
    public class press implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
           Game G=new Game();
           G.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
    
    }
    
     public class press1 implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
           int dialogButton = JOptionPane.YES_NO_OPTION;
           int dialogResult = JOptionPane.showConfirmDialog(null, "Do You Want To Exit The Game", "Confirm Exit", dialogButton);
           if(dialogResult == 0) {
               System.exit(0);           
           }          
        }
    
    }
    
}
