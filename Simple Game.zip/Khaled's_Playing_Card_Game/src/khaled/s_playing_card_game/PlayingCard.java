/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khaled.s_playing_card_game;

import javax.swing.JLabel;

/**
 *
 * @author Khaled
 */
public class PlayingCard {
    
    public String ImageName;
    public int CardName;
    public JLabel Holder;
    
}
