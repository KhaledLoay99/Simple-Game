/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khaled.s_playing_card_game;

import java.awt.event.MouseMotionListener;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
/**
 *
 * @author Khaled
 */
public class Game extends JFrame implements MouseMotionListener {
    public static ArrayList <PlayingCard> Cards=new ArrayList<PlayingCard>();
    String DirectoryPath="C:\\Users\\Khaled\\Desktop";
        PlayingCard p1=new PlayingCard();
        PlayingCard p2=new PlayingCard();
        PlayingCard p3=new PlayingCard();
        PlayingCard p4=new PlayingCard();
        PlayingCard p5=new PlayingCard();
        PlayingCard p6=new PlayingCard();
    public Game()
    {
      setTitle("Game");
      setSize(2000,2000);
     try {
            setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("C:\\Users\\Khaled\\Desktop\\Green.jpg")).getScaledInstance(2000, 2000, Image.SCALE_DEFAULT))));
        } catch (IOException e) {
        }
        pack();
        setVisible(true);
      
        p1.CardName=1;
        p1.ImageName=DirectoryPath+"\\"+"ace_of_spades.png";
        Cards.add(p1);
        JLabel j1=new JLabel();
        j1.setIcon(new ImageIcon(new ImageIcon(Cards.get(0).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j1);
        j1.addMouseMotionListener(this);
        j1.setBounds(290,10, 240, 320);
        p1.Holder=j1;   
        add(p1.Holder);
  
        
      
        p2.CardName=2;
        p2.ImageName=DirectoryPath+"\\"+"2_of_spades.png";
        Cards.add(p2);
        JLabel j2=new JLabel();
        j2.setIcon(new ImageIcon(new ImageIcon(Cards.get(1).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j2);
        j2.addMouseMotionListener(this);
        j2.setBounds(600,10, 240, 320);
        p2.Holder=j2;   
        add(p2.Holder);
     

        
        
        p3.CardName=3;
        p3.ImageName=DirectoryPath+"\\"+"3_of_clubs.png";
        Cards.add(p3);
        JLabel j3=new JLabel();
        j3.setIcon(new ImageIcon(new ImageIcon(Cards.get(2).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j3);
        j3.addMouseMotionListener(this);
        j3.setBounds(900,10, 240, 320);
        p3.Holder=j3; 
        add(p3.Holder);
     
        
                
        p4.CardName=4;
        p4.ImageName=DirectoryPath+"\\"+"4_of_spades.png";
        Cards.add(p4);
        JLabel j4=new JLabel();
        j4.setIcon(new ImageIcon(new ImageIcon(Cards.get(3).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j4);
        j4.addMouseMotionListener(this);
        j4.setBounds(1200,10, 240, 320);
        p4.Holder=j4; 
        add(p4.Holder);
        
        
        p5.CardName=5;
        p5.ImageName=DirectoryPath+"\\"+"5_of_clubs.png";
        Cards.add(p5);
        JLabel j5=new JLabel();
        j5.setIcon(new ImageIcon(new ImageIcon(Cards.get(4).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j5);
        j5.addMouseMotionListener(this);
        j5.setBounds(1500,10, 240, 320);
        p5.Holder=j5; 
        add(p5.Holder);
        
        
        p6.CardName=6;
        p6.ImageName=DirectoryPath+"\\"+"6_of_spades.png";
        Cards.add(p6);
        JLabel j6=new JLabel();
        j6.setIcon(new ImageIcon(new ImageIcon(Cards.get(5).ImageName).getImage().getScaledInstance(240, 320, Image.SCALE_DEFAULT)));
        add(j6);
        j6.addMouseMotionListener(this);
        j6.setBounds(290,55, 240, 320);
        p6.Holder=j6; 
        add(p6.Holder);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
        for (PlayingCard p1 :Cards) {
            if (p1.Holder.equals(e.getSource()))
            {
                p1.Holder.setBounds(e.getXOnScreen()-10,e.getYOnScreen()-20, 240, 320);
            }
        }
        if(p1.Holder.getX()==p2.Holder.getX()&&p1.Holder.getY()==p2.Holder.getY() && p1.CardName<p2.CardName){
          p1.Holder.setBounds(600,55,240,320);
        }else if( p4.Holder.getX()==p5.Holder.getX()&&p4.Holder.getY()==p5.Holder.getY()&& p4.CardName<p5.CardName){
          p4.Holder.setBounds(1500, 55, 240, 320);
        }else if(p3.Holder.getX()==p4.Holder.getX()&&p3.Holder.getY()==p4.Holder.getY() && p3.CardName<p4.CardName){
          p3.Holder.setBounds(1500,95, 240, 320);
        }else if(p5.Holder.getX()==p6.Holder.getX()&&p5.Holder.getY()==p6.Holder.getY() && p5.CardName<p6.CardName ){
          p5.Holder.setBounds(290,95, 240, 320);
          p4.Holder.setBounds(290,150, 240, 320);
          p3.Holder.setBounds(290,220, 240, 320);
        }else if(p2.Holder.getX()==p3.Holder.getX()&&p2.Holder.getY()==p3.Holder.getY() && p2.CardName<p3.CardName){
         p2.Holder.setBounds(290, 270, 240, 320);
         p1.Holder.setBounds(290, 320, 240, 320);
        }else if(e.getSource()==p6.Holder){
         JOptionPane.showMessageDialog(null, "You Win");
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }
    
    
    }